# HAS-12-3-Presc-Enoxaparine - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HAS-12-3-Presc-Enoxaparine**

## Example Bundle: HAS-12-3-Presc-Enoxaparine



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-12-3-Presc-Enoxaparine",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-HAS-12-3-Presc-Enoxaparine",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-HAS-12-3-Presc-Enoxaparine\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-HAS-12-3-Presc-Enoxaparine</b></p><a name=\"medication-HAS-12-3-Presc-Enoxaparine\"> </a><a name=\"hcmedication-HAS-12-3-Presc-Enoxaparine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090152}\">énoxaparine sodique</span></p><p><b>form</b>: <span title=\"Codes :{http://standardterms.edqm.eu 11201000}\">Solution injectable</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090152}\">énoxaparine sodique</span></td><td>4000 UI/0.4 ml<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmL = 'mL')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
          "code" : "100000090152",
          "display" : "énoxaparine sodique"
        }]
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "11201000",
          "display" : "Solution injectable"
        }]
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
            "code" : "100000090152",
            "display" : "énoxaparine sodique"
          }]
        },
        "strength" : {
          "numerator" : {
            "value" : 4000,
            "unit" : "UI"
          },
          "denominator" : {
            "value" : 0.4,
            "unit" : "ml",
            "system" : "http://unitsofmeasure.org",
            "code" : "mL"
          }
        }
      }]
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-12-3-Presc-Enoxaparine",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-HAS-12-3-Presc-Enoxaparine\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-12-3-Presc-Enoxaparine</b></p><a name=\"medicationrequest-HAS-12-3-Presc-Enoxaparine\"> </a><a name=\"hcmedicationrequest-HAS-12-3-Presc-Enoxaparine\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>Extension Definition for MedicationRequest.renderedDosageInstruction for Version 5.0</b>: </p><div><p>1 seringue, 1 fois toutes les 12 heures - voie sous-cutanée</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-HAS-12-3-Presc-Enoxaparine</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: ENOXAPARINE  4 000 UI (40 mg)/0,4 mL, solution injectable en seringue préremplie : 1 seringue, 1 fois toutes les 12 heures - voie sous-cutanée</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois par 12 hours</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20066000}\">Voie sous-cutanée</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Seringue<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15052000 = 'Syringe')</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "1 seringue, 1 fois toutes les 12 heures - voie sous-cutanée"
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medication-HAS-12-3-Presc-Enoxaparine"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: ENOXAPARINE  4 000 UI (40 mg)/0,4 mL, solution injectable en seringue préremplie : 1 seringue, 1 fois toutes les 12 heures - voie sous-cutanée"
      }],
      "dosageInstruction" : [{
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 12,
            "periodUnit" : "h"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20066000",
            "display" : "Voie sous-cutanée"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Seringue",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15052000"
          }
        }]
      }]
    }
  }]
}

```
