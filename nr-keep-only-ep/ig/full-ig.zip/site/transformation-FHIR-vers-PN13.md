# Transformation de FHIR vers PN13 - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* **Transformation de FHIR vers PN13**

## Transformation de FHIR vers PN13

### Transformation FHIR vers PN13

#### La conciliation

Prévu pour une version ultérieure de ce guide.

#### La prescription

Prévu pour une version ultérieure de ce guide.

#### La dispensation

Prévu pour une version ultérieure de ce guide.

