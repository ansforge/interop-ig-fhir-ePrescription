# MultiLine-Presc-METHOTREXATE-LEDERFOLINE - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MultiLine-Presc-METHOTREXATE-LEDERFOLINE**

## Example Bundle: MultiLine-Presc-METHOTREXATE-LEDERFOLINE

Profil: [FR Prescription Bundle For Example](StructureDefinition-fr-prescription-bundle-for-example.md)

Bundle MultiLine-Presc-METHOTREXATE-LEDERFOLINE de type searchset

-------

Entrée 1

Ressource MedicationRequest :

> **Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-METHOTREXATE**

Profil: [FR Inpatient MedicationRequest](StructureDefinition-fr-inpatient-medicationrequest.md)

**status**: Active**intent**: Option**priority**: Routine**medication**:METHOTREX.ACC 25MG/ML FL2ML**subject**:[Patient/30003](Patient/30003)**authoredOn**: 2025-05-02 14:48:44+0000**requester**:[Practitioner/smart-Practitioner-3003](Practitioner/smart-Practitioner-3003)**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/Presc-30003
> **dosageInstruction****timing**: Une fois**route**:Voie intramusculaire

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 2 Flacon(Détails : code EDQM Standard Terms15009000 = 'Bottle') |



-------

Entrée 2

Ressource MedicationRequest :

> **Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-LEDERFOLINE**

Profil: [FR Inpatient MedicationRequest](StructureDefinition-fr-inpatient-medicationrequest.md)

**status**: Active**intent**: Option**priority**: Routine**medication**:LEDERFOLINE 25MG CPR**subject**:[Patient/30003](Patient/30003)**authoredOn**: 2025-05-02 14:48:44+0000**requester**:[Practitioner/smart-Practitioner-3003](Practitioner/smart-Practitioner-3003)**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/Presc-30003
> **dosageInstruction****timing**: Une fois**route**:Voie orale

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 2 Comprimé(Détails : code EDQM Standard Terms15054000 = 'Tablet') |



-------

Entrée 3

Ressource RequestGroup :

> **Narratif généré : RequestGroup requestgroup-Presc-METHOTREXATE-LEDERFOLINE**

Profil: [FR RequestGroup For Prescription](StructureDefinition-fr-requestgroup-for-prescription.md)

**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/Presc-30003**status**: Active**intent**: Order**priority**: Routine**subject**:[Patient/30003](Patient/30003)
> **action**
> **id**Action1

### RelatedActions

| | | |
| :--- | :--- | :--- |
| - | **ActionId** | **Relationship** |
| * | Action2 | Concurrent |

**resource**:`#medicationrequest-Presc-LEDERFOLINE`

> **action**
> **id**Action2
**resource**:`#medicationrequest-Presc-METHOTREXATE`



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "MultiLine-Presc-METHOTREXATE-LEDERFOLINE",
  "meta" : {
    "profile" : [
      "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"
    ]
  },
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-Presc-METHOTREXATE",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-METHOTREXATE\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-METHOTREXATE</b></p><a name=\"medicationrequest-Presc-METHOTREXATE\"> </a><a name=\"hcmedicationrequest-Presc-METHOTREXATE\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Option</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400894357391}\">METHOTREX.ACC 25MG/ML FL2ML</span></p><p><b>subject</b>: <a href=\"Patient/30003\">Patient/30003</a></p><p><b>authoredOn</b>: 2025-05-02 14:48:44+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-3003\">Practitioner/smart-Practitioner-3003</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-30003</p><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20035000}\">Voie intramusculaire</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2 Flacon<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15009000 = 'Bottle')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "intent" : "option",
        "priority" : "routine",
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400894357391",
              "display" : "METHOTREX.ACC 25MG/ML FL2ML"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/30003"
        },
        "authoredOn" : "2025-05-02T14:48:44.461Z",
        "requester" : {
          "reference" : "Practitioner/smart-Practitioner-3003"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "Presc-30003"
        },
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2025-05-02T14:49:00Z",
                  "end" : "2025-05-30T14:48:59Z"
                },
                "frequency" : 1,
                "periodUnit" : "wk",
                "dayOfWeek" : ["fri"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20035000",
                  "display" : "Voie intramusculaire"
                }
              ],
              "text" : "Voie intramusculaire"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 2,
                  "unit" : "Flacon",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15009000"
                }
              }
            ]
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-Presc-LEDERFOLINE",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-LEDERFOLINE\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-LEDERFOLINE</b></p><a name=\"medicationrequest-Presc-LEDERFOLINE\"> </a><a name=\"hcmedicationrequest-Presc-LEDERFOLINE\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Option</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400891463088}\">LEDERFOLINE 25MG CPR</span></p><p><b>subject</b>: <a href=\"Patient/30003\">Patient/30003</a></p><p><b>authoredOn</b>: 2025-05-02 14:48:44+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-3003\">Practitioner/smart-Practitioner-3003</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-30003</p><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20053000}\">Voie orale</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "intent" : "option",
        "priority" : "routine",
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
              "code" : "3400891463088",
              "display" : "LEDERFOLINE 25MG CPR"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/30003"
        },
        "authoredOn" : "2025-05-02T14:48:44.461Z",
        "requester" : {
          "reference" : "Practitioner/smart-Practitioner-3003"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "Presc-30003"
        },
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2025-05-02T14:49:00Z",
                  "end" : "2025-05-30T14:48:59Z"
                },
                "frequency" : 1,
                "periodUnit" : "wk",
                "dayOfWeek" : ["fri"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20053000",
                  "display" : "Voie orale"
                }
              ],
              "text" : "Voie orale"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 2,
                  "unit" : "Comprimé",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15054000"
                }
              }
            ]
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "RequestGroup",
        "id" : "requestgroup-Presc-METHOTREXATE-LEDERFOLINE",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-requestgroup-for-prescription"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RequestGroup_requestgroup-Presc-METHOTREXATE-LEDERFOLINE\"> </a><p class=\"res-header-id\"><b>Narratif généré : RequestGroup requestgroup-Presc-METHOTREXATE-LEDERFOLINE</b></p><a name=\"requestgroup-Presc-METHOTREXATE-LEDERFOLINE\"> </a><a name=\"hcrequestgroup-Presc-METHOTREXATE-LEDERFOLINE\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-requestgroup-for-prescription.html\">FR RequestGroup For Prescription</a></p></div><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-30003</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>subject</b>: <a href=\"Patient/30003\">Patient/30003</a></p><blockquote><p><b>action</b></p><blockquote><p><b>id</b></p>Action1</blockquote><h3>RelatedActions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ActionId</b></td><td><b>Relationship</b></td></tr><tr><td style=\"display: none\">*</td><td>Action2</td><td>Concurrent</td></tr></table><p><b>resource</b>: <code>#medicationrequest-Presc-LEDERFOLINE</code></p></blockquote><blockquote><p><b>action</b></p><blockquote><p><b>id</b></p>Action2</blockquote><p><b>resource</b>: <code>#medicationrequest-Presc-METHOTREXATE</code></p></blockquote></div>"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "Presc-30003"
        },
        "status" : "active",
        "intent" : "order",
        "priority" : "routine",
        "subject" : {
          "reference" : "Patient/30003"
        },
        "action" : [
          {
            "id" : "Action1",
            "relatedAction" : [
              {
                "actionId" : "Action2",
                "relationship" : "concurrent"
              }
            ],
            "resource" : {
              "reference" : "#medicationrequest-Presc-LEDERFOLINE"
            }
          },
          {
            "id" : "Action2",
            "resource" : {
              "reference" : "#medicationrequest-Presc-METHOTREXATE"
            }
          }
        ]
      }
    }
  ]
}

```
