# Presc-MV-PerfGl-NaCl-KCl - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presc-MV-PerfGl-NaCl-KCl**

## Example Bundle: Presc-MV-PerfGl-NaCl-KCl

Profil: [FR Prescription Bundle For Example](StructureDefinition-fr-prescription-bundle-for-example.md)

Bundle Presc-MV-PerfGl-NaCl-KCl de type searchset

-------

Entrée 1

Ressource MedicationRequest :

> 

Profil: [FR Inpatient MedicationRequest](StructureDefinition-fr-inpatient-medicationrequest.md)

**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/Presc-14631**status**: Active**intent**: Order**priority**: Routine**subject**:[Patient/14602](Patient/14602)**authoredOn**: 2021-07-30 11:42:16+0000**requester**:[Practitioner/smart-Practitioner-71482713](Practitioner/smart-Practitioner-71482713)
> **dosageInstruction****timing**: Une fois**route**:Voie intraveineuse

### DoseAndRates

| | |
| :--- | :--- |
| - | **Rate[x]** |
| * | 500 ml(Détails : code UCUMmL = 'mL')/12 h(Détails : code UCUMh = 'h') |





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-MV-PerfGl-NaCl-KCl",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"
    ]
  },
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-Presc-MV-PerfGl-NaCl-KCl",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-MV-PerfGl-NaCl-KCl\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-MV-PerfGl-NaCl-KCl</b></p><a name=\"medicationrequest-Presc-MV-PerfGl-NaCl-KCl\"> </a><a name=\"hcmedicationrequest-Presc-MV-PerfGl-NaCl-KCl\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://BogusSystemMedicabase.com MV00004216}\">GLUCOSE 5 % + POTASSIUM CHLORURE 0,2 % + SODIUM CHLORURE 0,4 % sol p perf</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-30 11:42:16+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14631</p><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20045000}\">Voie intraveineuse</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Rate[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>500 ml<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmL = 'mL')</span>/12 h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "intent" : "order",
        "priority" : "routine",
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://BogusSystemMedicabase.com",
              "code" : "MV00004216",
              "display" : "GLUCOSE 5 % + POTASSIUM CHLORURE 0,2 % + SODIUM CHLORURE 0,4 % sol p perf"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/14602"
        },
        "authoredOn" : "2021-07-30T11:42:16.592Z",
        "requester" : {
          "reference" : "Practitioner/smart-Practitioner-71482713"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "Presc-14631"
        },
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2021-07-30T11:42:00Z",
                  "end" : "2021-08-04T11:41:59Z"
                },
                "timeOfDay" : ["10:00:00", "22:00:00"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20045000",
                  "display" : "Voie intraveineuse"
                }
              ],
              "text" : "Voie intraveineuse"
            },
            "doseAndRate" : [
              {
                "rateRatio" : {
                  "numerator" : {
                    "value" : 500,
                    "unit" : "ml",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "mL"
                  },
                  "denominator" : {
                    "value" : 12,
                    "unit" : "h",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "h"
                  }
                }
              }
            ]
          }
        ]
      }
    }
  ]
}

```
