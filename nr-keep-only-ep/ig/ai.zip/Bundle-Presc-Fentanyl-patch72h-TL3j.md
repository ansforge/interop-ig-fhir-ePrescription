# Presc-Fentanyl-patch72h-TL3j - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presc-Fentanyl-patch72h-TL3j**

## Example Bundle: Presc-Fentanyl-patch72h-TL3j

Profil: [FR Prescription Bundle For Example](StructureDefinition-fr-prescription-bundle-for-example.md)

Bundle Presc-Fentanyl-patch72h-TL3j de type searchset

-------

Entrée 1

Ressource Medication :

> 

Profil: [FR Medication Non Compound](StructureDefinition-fr-medication-noncompound.md)

**code**:FENTANYL
> **ingredient**

-------

Entrée 2

Ressource MedicationRequest :

> 

Profil: [FR Inpatient MedicationRequest](StructureDefinition-fr-inpatient-medicationrequest.md)

**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/Presc-14622**status**: Active**intent**: Order**priority**: Routine**subject**:[Patient/14602](Patient/14602)**authoredOn**: 2021-07-20 19:05:30+0000**requester**:[Practitioner/smart-Practitioner-71482713](Practitioner/smart-Practitioner-71482713)
> **dosageInstruction****timing**: Une fois par 3 days**route**:Voie transdermique

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 Patch(Détails : code EDQM Standard Terms15036000 = 'Patch') |





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-Fentanyl-patch72h-TL3j",
  "meta" : {
    "profile" : [
      "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"
    ]
  },
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "Medication",
        "id" : "medication-Presc-Fentanyl-patch72h-TL3j",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-medication-noncompound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-Presc-Fentanyl-patch72h-TL3j\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-Fentanyl-patch72h-TL3j</b></p><a name=\"medication-Presc-Fentanyl-patch72h-TL3j\"> </a><a name=\"hcmedication-Presc-Fentanyl-patch72h-TL3j\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090377}\">FENTANYL</span></p><p><b>form</b>: <span title=\"Codes :{http://standardterms.edqm.eu 0061}\">Patch</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090377}\">FENTANYL</span></td><td>75 µg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMug = 'ug')</span>/1 h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></td></tr></table></div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
              "code" : "100000090377",
              "display" : "fentanyl"
            }
          ],
          "text" : "FENTANYL"
        },
        "form" : {
          "coding" : [
            {
              "system" : "http://standardterms.edqm.eu",
              "code" : "0061",
              "display" : "Patch"
            }
          ]
        },
        "ingredient" : [
          {
            "itemCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
                  "code" : "100000090377",
                  "display" : "fentanyl"
                }
              ],
              "text" : "FENTANYL"
            },
            "strength" : {
              "numerator" : {
                "value" : 75,
                "unit" : "µg",
                "system" : "http://unitsofmeasure.org",
                "code" : "ug"
              },
              "denominator" : {
                "value" : 1,
                "unit" : "h",
                "system" : "http://unitsofmeasure.org",
                "code" : "h"
              }
            }
          }
        ]
      }
    },
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-Presc-Fentanyl-patch72h-TL3j",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-Fentanyl-patch72h-TL3j\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-Fentanyl-patch72h-TL3j</b></p><a name=\"medicationrequest-Presc-Fentanyl-patch72h-TL3j\"> </a><a name=\"hcmedicationrequest-Presc-Fentanyl-patch72h-TL3j\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-Presc-Fentanyl-patch72h-TL3j</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-20 19:05:30+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14622</p><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois par 3 days</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20070000}\">Voie transdermique</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Patch<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15036000 = 'Patch')</span></td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "intent" : "order",
        "priority" : "routine",
        "medicationReference" : {
          "reference" : "#medication-Presc-Fentanyl-patch72h-TL3j"
        },
        "subject" : {
          "reference" : "Patient/14602"
        },
        "authoredOn" : "2021-07-20T19:05:30.603Z",
        "requester" : {
          "reference" : "Practitioner/smart-Practitioner-71482713"
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "Presc-14622"
        },
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2021-07-20T19:05:00Z",
                  "end" : "2021-07-28T19:04:59Z"
                },
                "frequency" : 1,
                "period" : 3,
                "periodUnit" : "d",
                "timeOfDay" : ["07:00:00"]
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20070000",
                  "display" : "Voie transdermique"
                }
              ],
              "text" : "Voie transdermique"
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "Patch",
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "15036000"
                }
              }
            ]
          }
        ]
      }
    }
  ]
}

```
