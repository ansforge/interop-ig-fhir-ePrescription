# TradPN13FHIR-Presc-Morphine-PCA - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TradPN13FHIR-Presc-Morphine-PCA**

## Example Bundle: TradPN13FHIR-Presc-Morphine-PCA

Profil: [FR Prescription Bundle For Example](StructureDefinition-fr-prescription-bundle-for-example.md)

Bundle TradPN13FHIR-Presc-Morphine-PCA de type searchset

-------

Entrée 1

Ressource Patient :

> 

Profil: [FR Core Patient INS Profile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient-ins.html)

ARASGAIN Female, Date de Naissance :1989-01-02 ( Identifiant interne: 6032486 (use: usual, ))
-------

-------

Entrée 2

Ressource MedicationRequest :

> 

Profil: [FR Inpatient MedicationRequest](StructureDefinition-fr-inpatient-medicationrequest.md)

**identifier**: https://somehospital.fr/Medication-ID**groupIdentifier**:`https://somehospital.fr/Prescrption-ID`/10543745**status**: Active**intent**: Order**priority**: Routine**subject**:`#patient-Trad-Presc-Morphine-PCA`**encounter**: Identifier:`https://somehospital.fr/Sejour`/765093464568**supportingInformation**:
* Identifier: `https://somehospital.fr/UF`/603
* Identifier: `https://somehospital.fr/UF`/506
**authoredOn**: 2025-05-07 15:35:00+0200**requester**: Identifier:`urn:oid:1.2.250.1.71.4.2.1`/899999999999**note**:
> 

Prescription textuelle: Par voie intraveineuse : PCA Morphine 120 mg/24h Bolus 10 mg Période refractaire 2h -- À partir du 07/05/2025 à 17:30 jusqu'au 11/05/2025 à 17h30


> **dosageInstruction****timing**: Une fois**route**:Voie intraveineuse

### DoseAndRates

| | |
| :--- | :--- |
| - | **Rate[x]** |
| * | 5 mg(Détails : code UCUMmg = 'mg')/1 h(Détails : code UCUMh = 'h') |


> **dosageInstruction****timing**: Une fois par 2 hours**route**:Voie intraveineuse

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 10 mg(Détails : code UCUMmg = 'mg') |





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "TradPN13FHIR-Presc-Morphine-PCA",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"
    ]
  },
  "type" : "searchset",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "patient-Trad-Presc-Morphine-PCA",
        "meta" : {
          "profile" : [
            "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-ins"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_patient-Trad-Presc-Morphine-PCA\"> </a><p class=\"res-header-id\"><b>Narratif généré : Patient patient-Trad-Presc-Morphine-PCA</b></p><a name=\"patient-Trad-Presc-Morphine-PCA\"> </a><a name=\"hcpatient-Trad-Presc-Morphine-PCA\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-patient-ins.html\">FR Core Patient INS Profile</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">ARASGAIN  Female, Date de Naissance :1989-01-02 ( Identifiant interne: 6032486 (use: usual, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\">NIR définitif/289062913400149 (utilisation : official, )</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Noms alternatifs (voir plus bas)\">Nom alternatif :</td><td colspan=\"3\">MARSALI CUIMEANACH (Official)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The registered place of birth of the patient. A sytem may use the address.text if they don't store the birthPlace address in discrete elements.\"><a href=\"http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-birthPlace.html\">Patient Birth Place</a></td><td colspan=\"3\"></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Reliabilility of the patient's identity | Précision sur le degré de fiabilité de l'identité du patient (si provisoire, validé... avec la justification : quelle type de pièce d'identité ?) avec la méthode de collection\">FR Core Patient Ident Reliability Extension:</td><td colspan=\"3\"><ul><li>identityStatus: <a href=\"https://hl7.fr/ig/fhir/core/2.1.0/CodeSystem-fr-core-cs-v2-0445.html#fr-core-cs-v2-0445-VALI\">FR Core CodeSystem v2-0445 VALI</a>: Identité validée</li></ul></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "identityStatus",
                "valueCoding" : {
                  "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0445",
                  "code" : "VALI"
                }
              }
            ],
            "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-identity-reliability"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/patient-birthPlace",
            "valueAddress" : {
              "extension" : [
                {
                  "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-address-insee-code",
                  "valueCoding" : {
                    "system" : "https://mos.esante.gouv.fr/NOS/TRE_R13-Commune/FHIR/TRE-R13-Commune",
                    "code" : "29134"
                  }
                }
              ]
            }
          }
        ],
        "identifier" : [
          {
            "use" : "official",
            "type" : {
              "coding" : [
                {
                  "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
                  "code" : "INS-NIR",
                  "display" : "NIR définitif"
                }
              ]
            },
            "system" : "urn:oid:1.2.250.1.213.1.4.8",
            "value" : "289062913400149"
          },
          {
            "use" : "usual",
            "type" : {
              "coding" : [
                {
                  "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
                  "code" : "INTRN",
                  "display" : "Identifiant interne"
                }
              ]
            },
            "system" : "urn:oid:1.2.250.1.507454354.43654.2346659",
            "value" : "6032486"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "ARASGAIN"
          },
          {
            "extension" : [
              {
                "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-patient-birth-list-given-name",
                "valueString" : "MARSALI MORAG MAIREAD"
              }
            ],
            "use" : "official",
            "family" : "CUIMEANACH",
            "given" : ["MARSALI"]
          }
        ],
        "gender" : "female",
        "birthDate" : "1989-01-02"
      }
    },
    {
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "medicationrequest-Trad-Presc-Morphine-PCA",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Trad-Presc-Morphine-PCA\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Trad-Presc-Morphine-PCA</b></p><a name=\"medicationrequest-Trad-Presc-Morphine-PCA\"> </a><a name=\"hcmedicationrequest-Trad-Presc-Morphine-PCA\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>identifier</b>: https://somehospital.fr/Medication-ID</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000091372}\">morphine</span></p><p><b>subject</b>: <code>#patient-Trad-Presc-Morphine-PCA</code></p><p><b>encounter</b>: Identifier: <code>https://somehospital.fr/Sejour</code>/765093464568</p><p><b>supportingInformation</b>: </p><ul><li>Identifier: <code>https://somehospital.fr/UF</code>/603</li><li>Identifier: <code>https://somehospital.fr/UF</code>/506</li></ul><p><b>authoredOn</b>: 2025-05-07 15:35:00+0200</p><p><b>requester</b>: Identifier: <code>urn:oid:1.2.250.1.71.4.2.1</code>/899999999999</p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/10543745</p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: Par voie intraveineuse : PCA Morphine 120 mg/24h Bolus 10 mg Période refractaire 2h -- À partir du 07/05/2025 à 17:30 jusqu'au 11/05/2025 à 17h30</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20045000}\">Voie intraveineuse</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Rate[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>5 mg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg = 'mg')</span>/1 h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></td></tr></table></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Une fois par 2 hours</p><p><b>asNeeded</b>: <span title=\"Codes :\">bolus</span></p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20045000}\">Voie intraveineuse</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>10 mg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg = 'mg')</span></td></tr></table></blockquote></div>"
        },
        "identifier" : [
          {
            "value" : "https://somehospital.fr/Medication-ID"
          }
        ],
        "status" : "active",
        "intent" : "order",
        "priority" : "routine",
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
              "code" : "100000091372",
              "display" : "morphine"
            }
          ]
        },
        "subject" : {
          "reference" : "#patient-Trad-Presc-Morphine-PCA"
        },
        "encounter" : {
          "identifier" : {
            "system" : "https://somehospital.fr/Sejour",
            "value" : "765093464568"
          }
        },
        "supportingInformation" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-uf-role",
                "valueCode" : "UFHEB"
              }
            ],
            "type" : "Organization",
            "identifier" : {
              "system" : "https://somehospital.fr/UF",
              "value" : "603"
            }
          },
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-uf-role",
                "valueCode" : "UFMED"
              }
            ],
            "type" : "Organization",
            "identifier" : {
              "system" : "https://somehospital.fr/UF",
              "value" : "506"
            }
          }
        ],
        "authoredOn" : "2025-05-07T15:35:00+02:00",
        "requester" : {
          "identifier" : {
            "system" : "urn:oid:1.2.250.1.71.4.2.1",
            "value" : "899999999999"
          }
        },
        "groupIdentifier" : {
          "system" : "https://somehospital.fr/Prescrption-ID",
          "value" : "10543745"
        },
        "note" : [
          {
            "extension" : [
              {
                "url" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medicationrequest-note-scope",
                "valueCode" : "LIPRESCTXT"
              }
            ],
            "text" : "Prescription textuelle: Par voie intraveineuse : PCA Morphine 120 mg/24h Bolus 10 mg Période refractaire 2h -- À partir du 07/05/2025 à 17:30 jusqu'au 11/05/2025 à 17h30"
          }
        ],
        "dosageInstruction" : [
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2025-05-07T17:30:00+02:00",
                  "end" : "2025-05-11T17:30:00+02:00"
                }
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20045000",
                  "display" : "Voie intraveineuse"
                }
              ]
            },
            "doseAndRate" : [
              {
                "rateRatio" : {
                  "numerator" : {
                    "value" : 5,
                    "unit" : "mg",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "mg"
                  },
                  "denominator" : {
                    "value" : 1,
                    "unit" : "h",
                    "system" : "http://unitsofmeasure.org",
                    "code" : "h"
                  }
                }
              }
            ]
          },
          {
            "timing" : {
              "repeat" : {
                "boundsPeriod" : {
                  "start" : "2025-05-07T17:30:00+02:00",
                  "end" : "2025-05-11T17:30:00+02:00"
                },
                "frequencyMax" : 1,
                "period" : 2,
                "periodUnit" : "h"
              }
            },
            "asNeededCodeableConcept" : {
              "text" : "bolus"
            },
            "route" : {
              "coding" : [
                {
                  "system" : "http://standardterms.edqm.eu",
                  "code" : "20045000",
                  "display" : "Voie intraveineuse"
                }
              ]
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 10,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                }
              }
            ]
          }
        ]
      }
    }
  ]
}

```
