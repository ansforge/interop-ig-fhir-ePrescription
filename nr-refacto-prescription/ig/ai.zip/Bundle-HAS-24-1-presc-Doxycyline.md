# HAS-24-1-presc-Doxycyline - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HAS-24-1-presc-Doxycyline**

## Example Bundle: HAS-24-1-presc-Doxycyline



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-24-1-presc-Doxycyline",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-24-1-Presc-Doxycyline",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-HAS-24-1-Presc-Doxycyline\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-24-1-Presc-Doxycyline</b></p><a name=\"medicationrequest-HAS-24-1-Presc-Doxycyline\"> </a><a name=\"hcmedicationrequest-HAS-24-1-Presc-Doxycyline\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1 comprimé le soir. Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://BogusSystemMedicabase.com MV00000833}\">Doxycycline 100 mg comprimé</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: DOXYCYCLINE 100 mg comprime : 1 comprimé le soir. Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée</span></p><p><b>timing</b>: Soir, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "1 comprimé le soir. Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée"
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://BogusSystemMedicabase.com",
          "code" : "MV00000833",
          "display" : "Doxycycline 100 mg comprimé"
        }]
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: DOXYCYCLINE 100 mg comprime : 1 comprimé le soir. Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée"
      }],
      "dosageInstruction" : [{
        "additionalInstruction" : [{
          "text" : "Ne pas s’allonger dans l’heure qui suit la prise, utiliser une protection solaire adaptée"
        }],
        "timing" : {
          "repeat" : {
            "when" : ["EVE"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          }
        }]
      }]
    }
  }]
}

```
