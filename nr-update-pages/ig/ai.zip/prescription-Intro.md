# La prescription - Introduction - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Prescription**](prescription.md)
* **La prescription - Introduction**

## La prescription - Introduction

### Prescription

Le domaine couvert inclut les prescriptions hospitalières, les prescriptions de médecine de ville ainsi que les prescriptions hospitalières exécutables en ville (PHEV). Les spécifications sont issues des travaux du groupe de travail Interop’Santé. Ils s’appuient sur la version précédente du Guide d’Integration, des travaux de la HAS sur la structuration de la posologie pour les prescriptions de médecine de ville (lien à venir lorsque ces travaux seront publiés) et s’inspirent des profils européens pour la [prescription](http://hl7.eu/fhir/mpd) (profils en concertation lorsque ces travaux ont été menés).

#### Détail

* [Vue d’ensemble](prescription-VueEnsemble.md)
* [Cas d’usage](prescription-CasUsage.md)
* [Exemples](prescription-Exemples.md)

