# Presc-MATRIFEN-patch-TL72h - Guide d'implémentation de la ePrescription v0.1.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Presc-MATRIFEN-patch-TL72h**

## Example Bundle: Presc-MATRIFEN-patch-TL72h



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-MATRIFEN-patch-TL72h",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-Presc-MATRIFEN-patch-TL72h",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-Presc-MATRIFEN-patch-TL72h\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-MATRIFEN-patch-TL72h</b></p><a name=\"medication-Presc-MATRIFEN-patch-TL72h\"> </a><a name=\"hcmedication-Presc-MATRIFEN-patch-TL72h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400893183014}\">MATRIFEN® 75 ug/h, dispositif transdermique</span></p><p><b>form</b>: <span title=\"Codes :{http://standardterms.edqm.eu 10517500}\">dispositif cutané</span></p><h3>Ingredients</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td><td><b>IsActive</b></td><td><b>Strength</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090377}\">FENTANYL</span></td><td>true</td><td>75 µg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMug = 'ug')</span>/ h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></td></tr></table></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
          "code" : "3400893183014",
          "display" : "MATRIFEN 75µG/H DISP TRANS"
        }],
        "text" : "MATRIFEN® 75 ug/h, dispositif transdermique"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "10517500",
          "display" : "patch cutané"
        }],
        "text" : "dispositif cutané"
      },
      "ingredient" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
            "code" : "100000090377",
            "display" : "fentanyl"
          }],
          "text" : "FENTANYL"
        },
        "isActive" : true,
        "strength" : {
          "numerator" : {
            "value" : 75,
            "unit" : "µg",
            "system" : "http://unitsofmeasure.org",
            "code" : "ug"
          },
          "denominator" : {
            "unit" : "h",
            "system" : "http://unitsofmeasure.org",
            "code" : "h"
          }
        }
      }]
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-Presc-MATRIFEN-patch-TL72h",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-Presc-MATRIFEN-patch-TL72h\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-MATRIFEN-patch-TL72h</b></p><a name=\"medicationrequest-Presc-MATRIFEN-patch-TL72h\"> </a><a name=\"hcmedicationrequest-Presc-MATRIFEN-patch-TL72h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-Presc-MATRIFEN-patch-TL72h</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-29 16:14:13+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14629</p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Durée 72hours , Une fois par 72 hours</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20070000}\">Voie transdermique</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 patch<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15036000 = 'Patch')</span></td></tr></table></blockquote></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medication-Presc-MATRIFEN-patch-TL72h"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2021-07-29T16:14:13.817Z",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "groupIdentifier" : {
        "system" : "https://somehospital.fr/Prescrption-ID",
        "value" : "Presc-14629"
      },
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-29T16:14:00Z",
              "end" : "2021-08-06T16:13:59Z"
            },
            "duration" : 72,
            "durationUnit" : "h",
            "frequency" : 1,
            "period" : 72,
            "periodUnit" : "h",
            "timeOfDay" : ["07:00:00"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20070000",
            "display" : "Voie transdermique"
          }],
          "text" : "Voie transdermique"
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "patch",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15036000"
          }
        }]
      }]
    }
  }]
}

```
