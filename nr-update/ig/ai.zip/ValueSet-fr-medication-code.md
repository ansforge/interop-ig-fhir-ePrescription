# value set Interop'Santé - Codes identifiant les médicaments - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **value set Interop'Santé - Codes identifiant les médicaments**

## ValueSet: value set Interop'Santé - Codes identifiant les médicaments 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/eprescription/ValueSet/fr-medication-code | *Version*:0.1.0 |
| Draft as of 2026-01-23 | *Computable Name*:FRMedicationCodes |

 
Le jeu de valeurs à utiliser pour indiquer le médicament dans Medication.code.coding.code 

 **References** 

* [FR Medication Non Compound](StructureDefinition-fr-medication-noncompound.md)
* [FR Medication Request](StructureDefinition-fr-medicationrequest.md)

### Définition logique (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-medication-code",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/ValueSet/fr-medication-code",
  "version" : "0.1.0",
  "name" : "FRMedicationCodes",
  "title" : "value set Interop'Santé - Codes identifiant les médicaments",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-01-23T17:00:04+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [
    {
      "name" : "Interop'Santé",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://interopsante.org/"
        }
      ]
    },
    {
      "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://esante.gouv.fr"
        },
        {
          "system" : "email",
          "value" : "monserviceclient.annuaire@esante.gouv.fr"
        }
      ]
    }
  ],
  "description" : "Le jeu de valeurs à utiliser pour indiquer le médicament dans Medication.code.coding.code",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "FRANCE"
        }
      ]
    }
  ],
  "immutable" : false,
  "compose" : {
    "include" : [
      {
        "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD"
      },
      {
        "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS"
      },
      {
        "system" : "http://data.esante.gouv.fr/ansm/medicament/substance"
      }
    ]
  }
}

```
