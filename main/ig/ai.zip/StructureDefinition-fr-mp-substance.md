# FR Medicinal Product Substance - Guide d'implémentation de la ePrescription v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FR Medicinal Product Substance**

## Data Type Profile: FR Medicinal Product Substance 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-mp-substance | *Version*:0.1.0 |
| Draft as of 2025-11-25 | *Computable Name*:FRMPSubstance |

 
code for the medicinal product substance 

**Usages:**

* Use this DataType Profile: [FR Medication Non Compound](StructureDefinition-fr-medication-noncompound.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.eprescription|current/StructureDefinition/fr-mp-substance)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-mp-substance.csv), [Excel](StructureDefinition-fr-mp-substance.xlsx), [Schematron](StructureDefinition-fr-mp-substance.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-mp-substance",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-mp-substance",
  "version" : "0.1.0",
  "name" : "FRMPSubstance",
  "title" : "FR Medicinal Product Substance",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-11-25T08:22:04+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [
    {
      "name" : "Interop'Santé",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://interopsante.org/"
        }
      ]
    },
    {
      "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://esante.gouv.fr"
        },
        {
          "system" : "email",
          "value" : "monserviceclient.annuaire@esante.gouv.fr"
        }
      ]
    }
  ],
  "description" : "code for the medicinal product substance",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "FRANCE"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "orim",
      "uri" : "http://hl7.org/orim",
      "name" : "Ontological RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "CodeableConcept",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/CodeableConcept",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "CodeableConcept",
        "path" : "CodeableConcept",
        "short" : "RIUM Medicinal Product Substance",
        "example" : [
          {
            "label" : "Glucose",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
                  "code" : "100000078171",
                  "display" : "glucose"
                }
              ],
              "text" : "glucose"
            }
          },
          {
            "label" : "Périndopril tert-butylamine",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
                  "code" : "100000091602",
                  "display" : "périndopril tert-butylamine"
                }
              ],
              "text" : "périndopril tert-butylamine"
            }
          }
        ]
      },
      {
        "id" : "CodeableConcept.coding",
        "path" : "CodeableConcept.coding",
        "binding" : {
          "strength" : "required",
          "description" : "Medicinal product Substance",
          "valueSet" : "https://interop.esante.gouv.fr/ig/fhir/eprescription/ValueSet/fr-substance-code"
        }
      }
    ]
  }
}

```
