# HAS-30-1-Presc-Hydrocortisone - Guide d'implémentation de la ePrescription v1.1.0-ballot

## Exemple Bundle: HAS-30-1-Presc-Hydrocortisone



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "HAS-30-1-Presc-Hydrocortisone",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-HAS-30-1-Presc-Hydrocortisone",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medicationrequest"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr\" lang=\"fr\"><hr/><p><b>French</b></p><hr/><a name=\"MedicationRequest_medicationrequest-HAS-30-1-Presc-Hydrocortisone\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-HAS-30-1-Presc-Hydrocortisone</b></p><a name=\"medicationrequest-HAS-30-1-Presc-Hydrocortisone\"> </a><a name=\"hcmedicationrequest-HAS-30-1-Presc-Hydrocortisone\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medicationrequest.html\">FR Medication Request</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1 comprimé matin et 1 comprimé midi\nEn cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important, augmenter la quantité pour passer à : 2 comprimés matin et 2 comprimés midi. En cas de fièvre &gt; 40°C passer à : 2 comprimés matin, 2 comprimés midi et 2 comprimés à 16h.\nAvec un maximum de 6 comprimés par jour.</p>\n</div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes :{http://BogusSystemMedicabase.com MV00000089}\">HYDROCORTISONE 10 mg comprimé</span></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2025-07-23 10:33:00+0100</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>note</b>: </p><blockquote><div><p>Prescription textuelle: HYDROCORTISONE 10 mg : 1 comprimé matin et 1 comprimé midi\nEn cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important, augmenter la quantité pour passer à : 2 comprimés matin et 2 comprimés midi. En cas de fièvre &gt; 40°C passer à : 2 comprimés matin, 2 comprimés midi et 2 comprimés à 16h.\nAvec un maximum de 6 comprimés par jour. QSP 6 mois.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>timing</b>: Matin, Midi, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table><p><b>maxDosePerPeriod</b>: 6 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span>/1 jour<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMd = 'd')</span></p></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">En cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important</span></p><p><b>timing</b>: Matin, Midi, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table><p><b>maxDosePerPeriod</b>: 6 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span>/1 jour<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMd = 'd')</span></p></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>additionalInstruction</b>: <span title=\"Codes :\">En cas de fièvre &gt; 40°C</span></p><p><b>timing</b>: Matin, Midi, Une fois</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span></td></tr></table><p><b>maxDosePerPeriod</b>: 6 Comprimé<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15054000 = 'Tablet')</span>/1 jour<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMd = 'd')</span></p></blockquote></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
        "valueMarkdown" : "1 comprimé matin et 1 comprimé midi \nEn cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important, augmenter la quantité pour passer à : 2 comprimés matin et 2 comprimés midi. En cas de fièvre > 40°C passer à : 2 comprimés matin, 2 comprimés midi et 2 comprimés à 16h.\nAvec un maximum de 6 comprimés par jour."
      }],
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "http://BogusSystemMedicabase.com",
          "code" : "MV00000089",
          "display" : "HYDROCORTISONE 10 mg comprimé"
        }]
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2025-07-23T10:33:00+01:00",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "note" : [{
        "text" : "Prescription textuelle: HYDROCORTISONE 10 mg : 1 comprimé matin et 1 comprimé midi \nEn cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important, augmenter la quantité pour passer à : 2 comprimés matin et 2 comprimés midi. En cas de fièvre > 40°C passer à : 2 comprimés matin, 2 comprimés midi et 2 comprimés à 16h.\nAvec un maximum de 6 comprimés par jour. QSP 6 mois."
      }],
      "dosageInstruction" : [{
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 6,
              "unit" : "mois",
              "system" : "http://unitsofmeasure.org",
              "code" : "mo"
            },
            "when" : ["MORN", "NOON"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 6,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "jour",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        }
      },
      {
        "additionalInstruction" : [{
          "text" : "En cas de fièvre, de forte chaleur, d'infection, de diarrhée, de stress important"
        }],
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 6,
              "unit" : "mois",
              "system" : "http://unitsofmeasure.org",
              "code" : "mo"
            },
            "when" : ["MORN", "NOON"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 2,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 6,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "jour",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        }
      },
      {
        "additionalInstruction" : [{
          "text" : "En cas de fièvre > 40°C"
        }],
        "timing" : {
          "repeat" : {
            "boundsDuration" : {
              "value" : 6,
              "unit" : "mois",
              "system" : "http://unitsofmeasure.org",
              "code" : "mo"
            },
            "timeOfDay" : ["16:00:00"],
            "when" : ["MORN", "NOON"]
          }
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 2,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 6,
            "unit" : "Comprimé",
            "system" : "http://standardterms.edqm.eu",
            "code" : "15054000"
          },
          "denominator" : {
            "value" : 1,
            "unit" : "jour",
            "system" : "http://unitsofmeasure.org",
            "code" : "d"
          }
        }
      }]
    }
  }]
}

```
