# Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin - Guide d'implémentation de la ePrescription v1.1.0-ballot

## Example Bundle: Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr-FR\" lang=\"fr-FR\"><hr/><p><b>French (France)</b></p><hr/><a name=\"Medication_medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin</b></p><a name=\"medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><a name=\"hcmedication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/codeSMS 100000090270}\">PARACETAMOL</span></p></div></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/codeSMS",
          "code" : "100000090270",
          "display" : "paracétamol"
        }],
        "text" : "PARACETAMOL"
      }
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr-FR\" lang=\"fr-FR\"><hr/><p><b>French (France)</b></p><hr/><a name=\"MedicationRequest_medicationrequest-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin</b></p><a name=\"medicationrequest-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><a name=\"hcmedicationrequest-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-08-12 11:59:40+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14640</p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>additionalInstruction</b>: <span title=\"Codes :\">Délais minimum entre 2 prises : 4h</span></p><p><b>timing</b>: Une fois</p><p><b>asNeeded</b>: <span title=\"Codes :{http://snomed.info/sct 22253000}\">Si douleurs</span></p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20053000}\">Voie orale</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>500 mg<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg = 'mg')</span></td></tr></table><p><b>maxDosePerPeriod</b>: 3 g<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg = 'g')</span>/24 h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></p><p><b>maxDosePerAdministration</b>: 1 g<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg = 'g')</span></p></blockquote></div></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medication-Presc-Paracetamol-SiDouleur-MaxPrise-DelaisMin"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2021-08-12T11:59:40.552Z",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "groupIdentifier" : {
        "system" : "https://somehospital.fr/Prescrption-ID",
        "value" : "Presc-14640"
      },
      "dosageInstruction" : [{
        "sequence" : 1,
        "additionalInstruction" : [{
          "text" : "Délais minimum entre 2 prises : 4h"
        }],
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-08-12T11:59:00Z",
              "end" : "2021-08-17T11:58:59Z"
            },
            "frequencyMax" : 1,
            "periodMax" : 4,
            "periodUnit" : "h"
          }
        },
        "asNeededCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "22253000",
            "display" : "douleur"
          }],
          "text" : "Si douleurs"
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20053000",
            "display" : "Voie orale"
          }],
          "text" : "Voie orale"
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 500,
            "unit" : "mg",
            "system" : "http://unitsofmeasure.org",
            "code" : "mg"
          }
        }],
        "maxDosePerPeriod" : {
          "numerator" : {
            "value" : 3,
            "unit" : "g",
            "system" : "http://unitsofmeasure.org",
            "code" : "g"
          },
          "denominator" : {
            "value" : 24,
            "unit" : "h",
            "system" : "http://unitsofmeasure.org",
            "code" : "h"
          }
        },
        "maxDosePerAdministration" : {
          "value" : 1,
          "unit" : "g",
          "system" : "http://unitsofmeasure.org",
          "code" : "g"
        }
      }]
    }
  }]
}

```
