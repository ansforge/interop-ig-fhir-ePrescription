# Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h - Guide d'implémentation de la ePrescription v1.1.0-ballot

##  Bundle: Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-prescription-bundle-for-example"]
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-medication-noncompound"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr-FR\" lang=\"fr-FR\"><hr/><p><b>French (France)</b></p><hr/><a name=\"Medication_medication-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><p class=\"res-header-id\"><b>Narratif généré : Médication medication-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h</b></p><a name=\"medication-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><a name=\"hcmedication-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-medication-noncompound.html\">FR Medication Non Compound</a></p></div><p><b>code</b>: <span title=\"Codes :{http://data.esante.gouv.fr/ansm/medicament/UCD 3400893093542}\">BIONOLYTE® G5, sol pr perf, flac 500 mL</span></p><p><b>form</b>: <span title=\"Codes :{http://standardterms.edqm.eu 11210000}\">solution pour perfusion</span></p></div></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "http://data.esante.gouv.fr/ansm/medicament/UCD",
          "code" : "3400893093542",
          "display" : "BIONOLYTE G5 INJ FPE500ML"
        }],
        "text" : "BIONOLYTE® G5, sol pr perf, flac 500 mL"
      },
      "form" : {
        "coding" : [{
          "system" : "http://standardterms.edqm.eu",
          "code" : "11210000",
          "display" : "solution pour perfusion"
        }],
        "text" : "solution pour perfusion"
      }
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/eprescription/StructureDefinition/fr-inpatient-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"fr-FR\" lang=\"fr-FR\"><hr/><p><b>French (France)</b></p><hr/><a name=\"MedicationRequest_medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><p class=\"res-header-id\"><b>Narratif généré : PrescriptionMédicamenteuseTODO medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h</b></p><a name=\"medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><a name=\"hcmedicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-fr-inpatient-medicationrequest.html\">FR Inpatient MedicationRequest</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <code>#medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h</code></p><p><b>subject</b>: <a href=\"Patient/14602\">Patient/14602</a></p><p><b>authoredOn</b>: 2021-07-29 17:29:27+0000</p><p><b>requester</b>: <a href=\"Practitioner/smart-Practitioner-71482713\">Practitioner/smart-Practitioner-71482713</a></p><p><b>groupIdentifier</b>: <code>https://somehospital.fr/Prescrption-ID</code>/Presc-14630</p><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>timing</b>: Une fois</p><p><b>route</b>: <span title=\"Codes :{http://standardterms.edqm.eu 20045000}\">Voie intraveineuse</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Rate[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes :{http://terminology.hl7.org/CodeSystem/dose-rate-type ordered}\">Ordered</span></td><td>1 flacon<span style=\"background: LightGoldenRodYellow\"> (Détails : code EDQM Standard Terms15009000 = 'Bottle')</span>/12 h<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMh = 'h')</span></td></tr></table></blockquote></div></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationReference" : {
        "reference" : "#medicationrequest-Presc-SolPrPerf-BIONOLYTE-G5-500mL-Sur12h"
      },
      "subject" : {
        "reference" : "Patient/14602"
      },
      "authoredOn" : "2021-07-29T17:29:27.603Z",
      "requester" : {
        "reference" : "Practitioner/smart-Practitioner-71482713"
      },
      "groupIdentifier" : {
        "system" : "https://somehospital.fr/Prescrption-ID",
        "value" : "Presc-14630"
      },
      "dosageInstruction" : [{
        "sequence" : 1,
        "timing" : {
          "repeat" : {
            "boundsPeriod" : {
              "start" : "2021-07-29T17:29:00Z",
              "end" : "2021-08-03T17:28:59Z"
            },
            "timeOfDay" : ["10:00:00", "22:00:00"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://standardterms.edqm.eu",
            "code" : "20045000",
            "display" : "Voie intraveineuse"
          }],
          "text" : "Voie intraveineuse"
        },
        "doseAndRate" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/dose-rate-type",
              "code" : "ordered",
              "display" : "Ordered"
            }],
            "text" : "Ordered"
          },
          "rateRatio" : {
            "numerator" : {
              "value" : 1,
              "unit" : "flacon",
              "system" : "http://standardterms.edqm.eu",
              "code" : "15009000"
            },
            "denominator" : {
              "value" : 12,
              "unit" : "h",
              "system" : "http://unitsofmeasure.org",
              "code" : "h"
            }
          }
        }]
      }]
    }
  }]
}

```
